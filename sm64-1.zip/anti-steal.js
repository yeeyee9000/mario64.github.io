const container = document.getElementById('container');

if (container.textContent.includes('SM64-JS | Made by Chase Wicklund on replit! (@jscraft)')) {
  console.log('');
} else {
  console.log('Do not steal code. Here is the original repl. https://replit.com/@jscraft/sm64');
}